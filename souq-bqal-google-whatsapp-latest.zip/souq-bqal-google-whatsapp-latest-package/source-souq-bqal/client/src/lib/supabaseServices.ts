/* Souq Bqal — Auth, orders, list uploads and realtime helpers for the three app roles. */
import { requireSupabase } from "./supabase";

export async function sendPhoneOtp(phone: string) {
  return requireSupabase().auth.signInWithOtp({ phone });
}

export async function signInWithGoogle() {
  return requireSupabase().auth.signInWithOAuth({ provider: "google", options: { redirectTo: window.location.origin } });
}

export async function sendEmailOtp(email: string) {
  return requireSupabase().auth.signInWithOtp({
    email,
    options: { emailRedirectTo: window.location.origin },
  });
}

export async function getCurrentSession() {
  return requireSupabase().auth.getSession();
}

export async function verifyPhoneOtp(phone: string, token: string) {
  return requireSupabase().auth.verifyOtp({ phone, token, type: "sms" });
}

export async function signOut() {
  return requireSupabase().auth.signOut();
}

export async function createOrder(order: {
  customer_id: string;
  shop_id: string;
  payment_method: "cash" | "card";
  delivery_address: string;
  total: number;
}) {
  return requireSupabase().from("orders").insert({ ...order, status: "pending" }).select().single();
}

export async function uploadOrderList(orderId: string, file: File) {
  const client = requireSupabase();
  const path = `orders/${orderId}/${crypto.randomUUID()}-${file.name}`;
  const upload = await client.storage.from("order-lists").upload(path, file, { upsert: false, contentType: file.type });
  if (upload.error) return upload;
  return client.from("order_lists").insert({ order_id: orderId, image_path: path, review_status: "pending" }).select().single();
}

export function subscribeToOrder(orderId: string, onChange: (payload: unknown) => void) {
  const client = requireSupabase();
  const channel = client.channel(`order:${orderId}`).on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${orderId}` }, onChange).subscribe();
  return () => { void client.removeChannel(channel); };
}

export async function listShopOrders(shopId: string) {
  return requireSupabase().from("orders").select("*, order_items(*)").eq("shop_id", shopId).order("created_at", { ascending: false });
}

export async function updateOrderStatus(orderId: string, status: string) {
  return requireSupabase().from("orders").update({ status }).eq("id", orderId);
}
