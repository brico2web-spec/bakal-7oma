# سوق بقال — MVP Google + WhatsApp

## المسار المقترح

الزبون يدخل بحساب Google، يحدد الحي أو موقعه، يشوف الحوانت القريبة، يضيف المنتجات للسلة، ثم يضغط على زر WhatsApp. الموقع كينشئ رسالة منظمة فيها المنتجات، الكميات، المجموع وطريقة الدفع، ويفتح محادثة WhatsApp مع رقم البقال. البقال كيراجع الطلب ويرد بالتأكيد يدوياً.

البقال عنده صفحة `/vendor/register` لإدخال الاسم، اسم الحانوت، رقم WhatsApp بصيغة دولية، العنوان، أوقات العمل، والموقع. في النسخة الحالية النموذج تجريبي؛ الحفظ الحقيقي يحتاج ربطه بجدول `shops` في Supabase.

## إعداد Google في Supabase

من Supabase افتح `Authentication → Providers → Google` ثم فعّل Google. خاصك OAuth Client ID وClient Secret من Google Cloud Console. في Supabase أضف Redirect URL الذي يعطيه لك Supabase، ثم تأكد أن Site URL وRedirect URLs فيها رابط الموقع المنشور ورابط المعاينة أثناء التطوير.

## WhatsApp المجاني

النسخة الأولى تستعمل رابط `wa.me` مع رسالة جاهزة، لذلك الزبون هو الذي يضغط إرسال والبقال هو الذي يؤكد يدوياً. هذا لا يحتاج WhatsApp Business API، لكنه يحتاج رقم البقال بصيغة دولية بدون `+` أو مسافات، مثل `2126XXXXXXXX`.

## WhatsApp الآلي لاحقاً

إذا بغينا إرسال الطلبات والتأكيدات آلياً بدون ضغط الزبون، خاص WhatsApp Business Platform أو مزود رسمي، مع قوالب ورسائل وموافقة المستخدم. لا نستعمل خدمات غير رسمية أو أتمتة مخالفة لشروط WhatsApp.

## الجداول المقترحة

- `profiles`: هوية المستخدم ودوره (`customer`, `vendor`, `courier`).
- `shops`: اسم الحانوت، الهاتف، العنوان، latitude، longitude، ساعات العمل، وحالة النشاط.
- `products`: المنتجات والأسعار والمخزون وربطها بـ `shop_id`.
- `orders`: الزبون، البقال، المجموع، طريقة الدفع، الحالة، ورابط WhatsApp.
- `order_items`: المنتجات والكميات داخل الطلب.

## التشغيل

ضع `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY` في `.env.local` بجانب `package.json`، ثم شغّل `pnpm install` و`pnpm dev`. لا ترفع `.env.local` إلى GitHub.
