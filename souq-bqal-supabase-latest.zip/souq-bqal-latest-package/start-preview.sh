#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/preview"
echo "Souq Bqal preview: http://localhost:4173"
python3 -m http.server 4173
