# إعداد سوق بقال مع GitHub وSupabase

هذا المشروع الحالي عبارة عن واجهة React/Tailwind متجاوبة. يمكن رفعه مباشرة إلى مستودع GitHub ثم تشغيله محلياً بالأوامر التالية:

```bash
pnpm install
pnpm dev
```

لإنشاء نسخة production:

```bash
pnpm build
```

## GitHub

أنشئ مستودعاً جديداً، ثم من داخل مجلد المشروع نفّذ:

```bash
git init
git add .
git commit -m "Initial Souq Bqal interface"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Supabase

النسخة الحالية لا تحتوي بعد على قاعدة بيانات أو مصادقة أو API؛ البيانات الموجودة داخل الواجهة تجريبية للعرض. عند ربط Supabase، يُنصح بإنشاء جداول للمستخدمين، البقالين، المنتجات، الطلبات، عناصر الطلب، التوصيل، وصور لوائح الطلب. أضف مفاتيح Supabase في ملف `.env.local` ولا تضعها مباشرة داخل الكود أو GitHub.

مثال أسماء المتغيرات:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

بعد إضافة الربط، يمكن استعمال Supabase Storage لصور لوائح الطلب، وRealtime لتحديث حالة الطلب، وRow Level Security لحماية بيانات الزبون والبقال.

## ملاحظة

الملف لا يتضمن `node_modules` أو `dist` أو ملفات السجل الثقيلة. شغّل `pnpm install` بعد فك الضغط.
