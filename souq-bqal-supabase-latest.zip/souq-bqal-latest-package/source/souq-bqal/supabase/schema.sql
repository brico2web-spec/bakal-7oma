-- Souq Bqal / Supabase starter schema
create type public.user_role as enum ('customer', 'vendor', 'delivery');
create type public.order_status as enum ('pending', 'accepted', 'preparing', 'ready_for_pickup', 'out_for_delivery', 'delivered', 'rejected', 'cancelled');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  full_name text,
  role public.user_role not null default 'customer',
  default_address text,
  created_at timestamptz not null default now()
);

create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  name text not null,
  address text not null,
  latitude double precision,
  longitude double precision,
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  category text,
  price numeric(10,2) not null check (price >= 0),
  unit text,
  image_url text,
  stock_status text not null default 'available',
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  shop_id uuid not null references public.shops(id),
  delivery_id uuid references public.profiles(id),
  status public.order_status not null default 'pending',
  payment_method text not null check (payment_method in ('cash', 'card')),
  total numeric(10,2) not null default 0 check (total >= 0),
  delivery_address text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null check (unit_price >= 0)
);

create table if not exists public.order_lists (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  image_path text not null,
  review_status text not null default 'pending',
  confirmed_total numeric(10,2),
  created_at timestamptz not null default now()
);

create table if not exists public.delivery_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  actor_id uuid not null references public.profiles(id),
  status public.order_status not null,
  note text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_lists enable row level security;
alter table public.delivery_events enable row level security;

create policy "profiles own row" on public.profiles for select using (auth.uid() = id);
create policy "shops public read" on public.shops for select using (is_open = true or owner_id = auth.uid());
create policy "products public read" on public.products for select using (true);
create policy "customers create orders" on public.orders for insert with check (customer_id = auth.uid());
create policy "order participants read" on public.orders for select using (customer_id = auth.uid() or delivery_id = auth.uid() or exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy "vendors update own orders" on public.orders for update using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
