@echo off
cd /d "%~dp0preview"
echo Souq Bqal preview: http://localhost:4173
python -m http.server 4173
pause
